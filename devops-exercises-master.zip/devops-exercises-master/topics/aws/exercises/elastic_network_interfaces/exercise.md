## AWS EC2 - Elastic Network Interfaces

### Requirements

* An EC2 instance with network interface

### Objectives

A. Create a network interface and attach it to the EC2 instance that already has one network interface
B. Explain why would anyone use two network interfaces
