## OpenShift - Projects 101

### Objectives

In a newly deployed cluster (preferably) perform the following:

1. Log in to the OpenShift cluster
2. List all the projects
3. Create a new project called 'neverland'
4. Check the overview status of the current project
