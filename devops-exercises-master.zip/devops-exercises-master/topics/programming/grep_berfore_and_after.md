Implement the following grep command in Python (numbers can be different): `grep error -A 2 -B 2 some_file`
