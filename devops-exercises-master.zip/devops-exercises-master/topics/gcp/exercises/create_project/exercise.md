# Create a Project

## Objectives

1. Create a project with a unique name

## Solution

Click [here](solution.md) to view the solution